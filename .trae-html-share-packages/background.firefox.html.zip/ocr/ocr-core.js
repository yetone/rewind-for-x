// OCR core: download language data + read text from images with Tesseract.
// No message-passing here — just call read({src, langs}) and get {text}.
// Exposes globalThis.OCR for both offscreen (Chrome) and background (Firefox).
'use strict';

(function (global) {
  const DATA = 'https://cdn.jsdelivr.net/npm/@tesseract.js-data';
  const IDLE = 30_000;
  const MIN_CONFIDENCE = 60;

  let worker = null;
  let workerLangs = '';
  let idleTimer = 0;

  // ---------------------------------------------------------------- storage

  function db() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open('keyval-store');
      req.onupgradeneeded = () => req.result.createObjectStore('keyval');
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  async function idb(mode, fn) {
    const d = await db();
    try {
      return await new Promise((resolve, reject) => {
        const tx = d.transaction('keyval', mode);
        const req = fn(tx.objectStore('keyval'));
        tx.oncomplete = () => resolve(req.result);
        tx.onerror = () => reject(tx.error);
      });
    } finally {
      d.close();
    }
  }
  const cacheKey = (lang) => `./${lang}.traineddata`;
  const cached = async (lang) => (await idb('readonly', (s) => s.getKey(cacheKey(lang)))) !== undefined;

  // Download what isn't cached yet, reporting progress via onProgress callback.
  async function download(langs, onProgress) {
    const missing = [];
    for (const l of langs) if (!(await cached(l))) missing.push(l);
    if (!missing.length) return;
    const got = new Map(missing.map((l) => [l, 0]));
    const total = new Map();
    let sent = -1;
    const report = () => {
      let sum = 0;
      for (const l of missing) sum += total.get(l) ? got.get(l) / total.get(l) : 0;
      const p = Math.floor((sum / missing.length) * 100) / 100;
      if (p === sent) return;
      sent = p;
      if (onProgress) onProgress(p);
    };
    report();
    await Promise.all(missing.map(async (lang) => {
      const url = `${DATA}/${lang}/4.0.0_best_int/${lang}.traineddata.gz`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(`${url}: ${res.status}`);
      total.set(lang, Number(res.headers.get('content-length')) || 0);
      const reader = res.body.getReader();
      const parts = [];
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        parts.push(value);
        got.set(lang, got.get(lang) + value.length);
        report();
      }
      const data = new Uint8Array(await new Blob(parts).arrayBuffer());
      await idb('readwrite', (s) => s.put(data, cacheKey(lang)));
    }));
  }

  // ---------------------------------------------------------------- worker

  function url(p) {
    // In an extension context runtime.getURL works; in tests/other hosts we fall back to relative.
    try { return chrome.runtime.getURL(p); } catch { return p; }
  }

  async function getWorker(langs, onProgress) {
    const key = langs.join('+');
    if (worker && workerLangs === key) return worker;
    if (worker) await worker.terminate().catch(() => {});
    worker = null;
    await download(langs, onProgress);
    // Tesseract global comes from tesseract.min.js loaded before this file.
    worker = await Tesseract.createWorker(key, Tesseract.OEM.LSTM_ONLY, {
      workerPath: url('ocr/worker.min.js'),
      corePath: url('ocr/tesseract-core-simd-lstm.js'),
      langPath: `${DATA}/${langs[0]}/4.0.0_best_int`,
      workerBlobURL: false,
      cacheMethod: 'readOnly',
    });
    await worker.setParameters({ tessedit_pageseg_mode: Tesseract.PSM.SPARSE_TEXT });
    workerLangs = key;
    return worker;
  }

  // ---------------------------------------------------------------- text of result

  const CJK = '\\u2e80-\\u9fff\\uac00-\\ud7af\\uf900-\\ufaff\\uff00-\\uffef';
  const BETWEEN_CJK = new RegExp(`(?<=[${CJK}])\\s+(?=[${CJK}])`, 'g');
  const WORDLIKE = /[\p{L}\p{N}]{2,}/u;

  function textOf(data) {
    const lines = [];
    for (const b of data.blocks || []) {
      for (const p of b.paragraphs || []) {
        for (const l of p.lines || []) {
          const words = l.words
            .filter((w) => w.confidence >= MIN_CONFIDENCE)
            .map((w) => w.text.trim())
            .filter(Boolean);
          const line = words.join(' ').replace(BETWEEN_CJK, '');
          if (WORDLIKE.test(line)) lines.push(line);
        }
      }
    }
    return lines.join('\n');
  }

  // ---------------------------------------------------------------- public API

  async function read({ src, langs }, onProgress) {
    clearTimeout(idleTimer); // no idle shutdown while a read is in flight
    try {
      const w = await getWorker(langs, onProgress);
      let image;
      try {
        const res = await fetch(src);
        if (!res.ok) return { text: '' };
        image = await res.blob();
      } catch {
        return { text: '' };
      }
      try {
        const { data } = await w.recognize(image, {}, { text: false, blocks: true });
        return { text: textOf(data) };
      } catch {
        return { text: '' };
      }
    } finally {
      // Only once the read settles do we start the quiet spell after which the
      // worker is let go — never in the middle of a slow recognition.
      clearTimeout(idleTimer);
      idleTimer = setTimeout(() => {
        worker?.terminate().catch(() => {});
        worker = null;
      }, IDLE);
    }
  }

  global.OCR = { read };
})(typeof window !== 'undefined' ? window : globalThis);
