// Offscreen document for Chrome MV3: Tesseract lives here (sandboxed, keeps
// the service worker alive). Just forwards messages from background.js to OCR.
'use strict';

chrome.runtime.onMessage.addListener((m, _sender, reply) => {
  if (m?.target !== 'ocr') return;
  OCR.read(m, (progress) => {
    chrome.runtime.sendMessage({ type: 'ocr-progress', progress }).catch(() => {});
  })
    .then(reply, (e) => reply({ error: String(e?.message || e) }));
  return true;
});
