#!/bin/sh
# Builds dist/rewind-for-x-<version>.zip for the Chrome Web Store and
# dist/rewind-for-x-firefox-<version>.zip for addons.mozilla.org.
set -eu
cd "$(dirname "$0")/.."
version=$(sed -n 's/.*"version": *"\([^"]*\)".*/\1/p' manifest.json)
mkdir -p dist

rm -f "dist/rewind-for-x-$version.zip"
zip -qrX "dist/rewind-for-x-$version.zip" manifest.json background.js content.js _locales icons ocr -x '*.DS_Store'
echo "--- Chrome: dist/rewind-for-x-$version.zip ---"
unzip -l "dist/rewind-for-x-$version.zip"

rm -f "dist/rewind-for-x-firefox-$version.zip"
zip -qrX "dist/rewind-for-x-firefox-$version.zip" manifest.firefox.json background.firefox.html background.js content.js _locales icons ocr -x '*.DS_Store'
echo "--- Firefox: dist/rewind-for-x-firefox-$version.zip ---"
unzip -l "dist/rewind-for-x-firefox-$version.zip"
